﻿namespace JobHunters.Models
{
    public enum OfferType
    {  
        Gold = 1,
        Platinum=2,
        Silver=3
    }
}
