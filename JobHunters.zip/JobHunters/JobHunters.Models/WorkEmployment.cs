﻿namespace JobHunters.Models
{
    public enum WorkEmployment
    {
        FullTime=1,
        PartTime=2,
        HalfDay=3
    }
}
