﻿using System.Web.UI;

namespace JobHunters.WebFormsClient.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}